package ar.org.centro8.curso.laboratorio2.Laboratorio2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Laboratorio2Application {

	public static void main(String[] args) {
		SpringApplication.run(Laboratorio2Application.class, args);
	}

}
